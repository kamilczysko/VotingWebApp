package com.kamli.VoteApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoteAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(VoteAppApplication.class, args);
	}

}
